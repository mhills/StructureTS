﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EcommJewellery.Data;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace EcommJewellery.VariableTemplate
{
    public class VariableTiles : DataTemplateSelector
    {

        public DataTemplate NecklacesBigTemplate { get; set; }
        public DataTemplate NecklacesSmallTemplate { get; set; }
        public DataTemplate RingsTemplate { get; set; }
        public DataTemplate BraceletsBigTemplate { get; set; }
        public DataTemplate BraceletsSmallTemplate { get; set; }
        public DataTemplate EarringsBigTemplate { get; set; }
        public DataTemplate EarringsSmallPTemplate { get; set; }
        public DataTemplate EarringsSmallLTemplate { get; set; }
        
    
      

        protected override DataTemplate SelectTemplateCore(object item, DependencyObject container)
        {
            FrameworkElement element = container as FrameworkElement;

            if (element != null && item != null)
            {
                if (item.GetType() == typeof(SampleDataItem))
                {

                    if ((item as SampleDataItem).UniqueId.StartsWith("NecklacesBig"))
                        return NecklacesBigTemplate;
                    if ((item as SampleDataItem).UniqueId.StartsWith("NecklacesSmall"))
                        return NecklacesSmallTemplate;
                    if ((item as SampleDataItem).UniqueId.StartsWith("Rings"))
                        return RingsTemplate;
                    if ((item as SampleDataItem).UniqueId.StartsWith("BraceletsBig"))
                        return BraceletsBigTemplate;
                    if ((item as SampleDataItem).UniqueId.StartsWith("BraceletsSmall"))
                        return BraceletsSmallTemplate;
                    if ((item as SampleDataItem).UniqueId.StartsWith("EarringsBig"))
                        return EarringsBigTemplate;
                    if ((item as SampleDataItem).UniqueId.StartsWith("EarringsSmallP"))
                        return EarringsSmallPTemplate;
                    if ((item as SampleDataItem).UniqueId.StartsWith("EarringsSmallL"))
                        return EarringsSmallLTemplate;


                }

                else if (item.GetType() == typeof(NecklacesDataItem))
                {
                    if ((item as NecklacesDataItem).UniqueId.StartsWith("NecklacesBig"))
                        return NecklacesBigTemplate;
                    if ((item as NecklacesDataItem).UniqueId.StartsWith("NecklacesSmall"))
                        return NecklacesSmallTemplate;
                }


                else if (item.GetType() == typeof(PartyDataItem))
                {
                    if ((item as PartyDataItem).UniqueId.StartsWith("NecklacesBig"))
                        return NecklacesBigTemplate;
                    if ((item as PartyDataItem).UniqueId.StartsWith("NecklacesSmall"))
                        return NecklacesSmallTemplate;
                }

            }
            return base.SelectTemplateCore(item, container);
        }

    }
}
